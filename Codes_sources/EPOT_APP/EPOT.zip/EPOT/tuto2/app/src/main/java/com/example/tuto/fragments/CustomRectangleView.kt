package com.example.tuto.fragments

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class CustomRectangleView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private val paint = Paint().apply {
        color = Color.RED
        style = Paint.Style.FILL
    }
    private var height = 0f

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        canvas?.let {
            val width = width.toFloat()
            val rect = RectF(0f,0f  ,width ,height.toFloat() )
            it.drawRect(rect, paint)
        }
    }

    fun setLength(newHeight: Float) {
        height = newHeight
        invalidate()
    }
}