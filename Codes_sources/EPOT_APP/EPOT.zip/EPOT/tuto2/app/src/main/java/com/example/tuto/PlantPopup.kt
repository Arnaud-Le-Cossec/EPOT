package com.example.tuto

import android.app.Dialog
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.tuto.adapter.PlantAdapter
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlin.concurrent.thread

class PlantPopup(
    private val adapter: PlantAdapter,
    private val currentPlant: PlantModel
    ) : Dialog(adapter.context) {

    private val databaseRefPot = FirebaseDatabase.getInstance().getReference("EPOT1")
    private var iD = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.popup_plants_details)
        setupComponents()
        setupCloseButton()
        setupDeleteButton()
        setupStarButton()
        setupCheckButton()

        databaseRefPot.addValueEventListener (object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {


                //vérifie que la plante sélectionner est déjà celle choisi par l'utilisteur
                val check= findViewById<ImageView>(R.id.checkmark_button)

                iD= dataSnapshot.child("ID").getValue(String::class.java)!!
                //findViewById<TextView>(R.id.actual_plant).text=iD
                if (iD!=currentPlant.id){
                    check.setImageResource(R.drawable.void_image)
                }else{
                    check.setImageResource(R.drawable.ic_check)
                }

            }

            override fun onCancelled(databaseError: DatabaseError) {

            }
        })

    }

    private fun updateLightThreshold( new : Int){
        databaseRefPot.child("CMD").child("5_CMD_Light_threshold").setValue(new)
        Thread.sleep(100)
        databaseRefPot.child("CMD").child("8_CMD_UV_threshold").setValue(new)

    }


    //update la base de donnée pour la pante chosi par l'utilisateur
    private fun setupCheckButton(){

        val checkCaseButton=findViewById<ImageView>(R.id.check_case_button)

        checkCaseButton.setOnClickListener{
            databaseRefPot.child("ID").setValue("1")
            databaseRefPot.child("ID").setValue(currentPlant.id)
            val lightPlant=currentPlant.grow.toString()
            when (lightPlant) {
                "toujours allumé" -> {
                    updateLightThreshold(100)
                }
                "éclairage vif" -> {
                    updateLightThreshold(80)
                }
                "éclairage modéré" -> {
                    updateLightThreshold(60)
                }
                "éclairage tamisé" -> {
                    updateLightThreshold(40)
                }
                "éclairage faible" -> {
                    updateLightThreshold(20)
                }
                "jamais" -> {
                    updateLightThreshold(0)
                }
            }
            Thread.sleep(100)
            val waterPlant=currentPlant.water.toString()
            when (waterPlant) {
                "10%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(10)
                }
                "20%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(20)
                }
                "30%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(30)
                }
                "40%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(40)
                }
                "50%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(50)
                }
                "60%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(60)
                }
                "70%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(70)
                }
                "80%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(80)
                }
                "90%" -> {
                    databaseRefPot.child("CMD").child("1_CMD_Humidity_threshold").setValue(90)
                }
            }
            Thread.sleep(100)
        }

    }

    private fun updateStar(button: ImageView){
        if(currentPlant.liked) {
            button.setImageResource(R.drawable.ic_star)
        }
        else {
            button.setImageResource(R.drawable.ic_unstar)
        }
    }

    private fun setupStarButton() {
        //recuperer
        val starButton = findViewById<ImageView>(R.id.star_button)

        updateStar(starButton)

        //interaction
        starButton.setOnClickListener{
            currentPlant.liked  = !currentPlant.liked
            val repo = PlantRepository()
            repo.updatePlant(currentPlant)
            updateStar(starButton)
        }
    }

    private fun setupDeleteButton() {
        findViewById<ImageView>(R.id.delete_button).setOnClickListener{
            //supprimer la plante de la base
            val repo = PlantRepository()
            repo.deletePlant(currentPlant)
            dismiss()
        }
    }

    private fun setupCloseButton(){
        findViewById<ImageView>(R.id.close_button).setOnClickListener(){
            // fermer la fenetre
            dismiss()
        }
    }

    private fun setupComponents() {
        // actualiser l'image de la plante
        val plantImage = findViewById<ImageView>(R.id.image_item)
        Glide.with(adapter.context).load(Uri.parse(currentPlant.imageUrl)).into(plantImage)

        //actualiser le nom de la plante
        findViewById<TextView>(R.id.popup_plant_name).text = currentPlant.name

        //actualiser la description de la plante
        findViewById<TextView>(R.id.popup_plant_description_subtitle).text = currentPlant.description

        //actualiser la croissance de la plante
        val lightPlant= currentPlant.grow.toString()
        findViewById<TextView>(R.id.popup_plant_grow_subtitle).text = currentPlant.grow.toString()

        // actualiser la consomation d'eau de la plante
        findViewById<TextView>(R.id.popup_plant_water_subtitle).text = currentPlant.water.toString()

    }

}