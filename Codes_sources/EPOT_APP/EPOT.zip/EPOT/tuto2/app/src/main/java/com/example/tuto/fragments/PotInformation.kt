package com.example.tuto.fragments

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Context.NOTIFICATION_SERVICE
import android.os.Build
import androidx.core.app.NotificationCompat

import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.ProgressDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.ShortcutManager
import android.graphics.Matrix
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.RotateAnimation
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.tuto.MainActivity
import com.example.tuto.R
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.io.IOException
import java.util.*


class PotInformation (
    private val context : MainActivity
) : Fragment(){


    private lateinit var shortcutManager: ShortcutManager


    companion object {

        var m_myUUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        var m_bluetoothSocket: BluetoothSocket? = null
        lateinit var m_progress: ProgressDialog
        var m_isConnected: Boolean = false
        lateinit var m_address: String
    }

    private fun sendCommand(input: String) {
        if (m_bluetoothSocket != null) {
            try{
                m_bluetoothSocket!!.outputStream.write(input.toByteArray())
                showToast("Bluetooth is already on")
            } catch(e: IOException){
                e.printStackTrace()
            }
        }
    }








    //création layout
    @SuppressLint("MissingPermission", "MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater?.inflate(R.layout.pot_information, container, false)

        //text


        val waterTank=view?.findViewById<ImageView>(R.id.water_level)
        val autoLightButton=view?.findViewById<Button>(R.id.auto_light_button)
        val temperatureIndicator=view?.findViewById<TextView>(R.id.temperature_indicator)
        val autoWateringButton=view?.findViewById<Button>(R.id.auto_water_button)
        val forceWatering=view?.findViewById<ImageButton>(R.id.water_button)
        val warningWatering=view?.findViewById<TextView>(R.id.warning_message_force_watering)
        val sliderLight = view?.findViewById<SeekBar>(R.id.slider_light)
        val lightLevel = view?.findViewById<TextView>(R.id.light_level)
        val sliderUVLight = view?.findViewById<SeekBar>(R.id.slider_UV_light)
        val lightUVLevel = view?.findViewById<TextView>(R.id.light_UV_level)
        val temperatureVisual = view?.findViewById<ImageView>(R.id.temperature_dard)
        temperatureVisual!!.bringToFront()
        val lightVisualIndicator = view?.findViewById<ImageView>(R.id.light_indicator)
        val lightText = view?.findViewById<TextView>(R.id.light_text)
        val humidityText = view?.findViewById<TextView>(R.id.humidity_indicator)
        val waterPercentage = view?.findViewById<TextView>(R.id.pourcentage_eau)








        val databaseRefPot = FirebaseDatabase.getInstance().getReference("EPOT1")

        var waterAuto : Any = 1
        var watering : Any = 1
        var water : Long = 1
        var lightSensor= 1f
        var lightForce =1
        var lightIntensity =1
        var lightUVIntensity =1
        var autoLight = true
        var temperature: Float
        var lastPositionAiguille =1f
        var lastPositionLightIndicator = 1f
        val EPOT =databaseRefPot
        val test =view?.findViewById<ImageButton>(R.id.light_button)
        var waterForce= true
        var moisture = 1f
        var notification= true






        //création notification
        // Créer un identifiant unique pour la notification
        val notificationId = 1

// Créer un canal de notification (nécessaire pour les versions d'Android >= Oreo)
        val channelId = "my_channel_id"
        val channelName = "My Channel"
        val channelDescription = "Description of my channel"

        val notificationBuilder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.plante)
            .setContentTitle("Niveau d'eau!!!")
            .setContentText("attention votre EPOT n'as plus d'eau dans le reservoir")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

// Créer le gestionnaire de notification
        val notificationManager = context.getSystemService(NOTIFICATION_SERVICE) as NotificationManager

// Vérifier si le canal de notification doit être créé (versions d'Android >= Oreo)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = channelDescription
            // Ajouter le canal de notification au gestionnaire de notification
            notificationManager.createNotificationChannel(channel)
        }

// Afficher la notification





        //gestion de l'aiguille indiquant la température
        fun rotationAiguille(temp : Float) {

            val rotateAnimation = RotateAnimation(lastPositionAiguille, (temp+10f) *3f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f)
            rotateAnimation.duration = 100 // Durée de l'animation en millisecondes
            rotateAnimation.fillAfter = true // Conserve la position finale de l'animation
            lastPositionAiguille= (temp+10f) *3f
            temperatureVisual!!.startAnimation(rotateAnimation)

        }

        //gestion de l'indicateur de luminosité
        fun rotationLightIndicator(Light : Float) {

            val rotateAnimation = RotateAnimation(lastPositionLightIndicator, Light*2.1f+180f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f)
            rotateAnimation.duration = 100 // Durée de l'animation en millisecondes
            rotateAnimation.fillAfter = true // Conserve la position finale de l'animation
            lastPositionLightIndicator= Light*2.1f+180f
            lightVisualIndicator!!.startAnimation(rotateAnimation)

        }


        //création d'un minuteur pour les notification
        val countdownDuration = 5 * 60 * 1000 // Durée du minuteur en millisecondes (5 minutes)

        val countDownTimer = object : CountDownTimer(countdownDuration.toLong(), 1000) {
            override fun onTick(millisUntilFinished: Long) {
                // À chaque tick du minuteur (toutes les secondes),
                // vous pouvez effectuer des actions si nécessaire
                val timeRemaining = millisUntilFinished / 1000 // Temps restant en secondes
                println("Temps restant : $timeRemaining secondes")
            }

            override fun onFinish() {
                // À la fin du minuteur (après 5 minutes),
                // vous pouvez effectuer les actions souhaitées
                println("Minuteur terminé")
                notification=true

                // Changer la valeur ou effectuer une action spécifique ici
            }
        }


        //regarde si la base de données est mise à jour et execute le code
        EPOT.addValueEventListener(object : ValueEventListener
        {

            override fun onDataChange(snapshot: DataSnapshot) {
                val CMD = snapshot.child("CMD")


                //recupere la valeur de la base de données
                lightForce = CMD.child("6_CMD_Light_manual_intensity").getValue(Long::class.java)!!.toInt()
                water = snapshot.child("SENSOR_Water_level").getValue(Long::class.java)!!
                val lightAuto = CMD.child("7_CMD_Light_manual_auto").getValue(Boolean::class.java)
                temperature = snapshot.child("SENSOR_Temperature").getValue(Float::class.java)!!
                waterAuto = CMD.child("4_CMD_Watering_manual_auto").getValue(Boolean::class.java)!!
                waterForce = CMD.child("2_CMD_Pump_manual_on_off").getValue(Boolean::class.java)!!
                lightSensor =snapshot.child("SENSOR_Light").getValue(Float::class.java)!!
                moisture = snapshot.child("SENSOR_Humidity").getValue(Float::class.java)!!




                if (lightAuto != null) {
                    autoLight=lightAuto
                }

                //change l'affichage des bouttons manuel et auto
                if(lightAuto==false){
                    autoLightButton?.text="AUTO"
                    test?.visibility =View.INVISIBLE
                }else{
                    autoLightButton?.text="MANUAL"
                    test?.visibility =View.VISIBLE
                }

                if(waterAuto==true){
                    autoWateringButton?.text="MANUAL"
                    forceWatering?.visibility =View.VISIBLE
                }else{
                    autoWateringButton?.text="AUTO"

                    forceWatering?.visibility =View.INVISIBLE
                }

                //gestion de l'affichage du niveau d'eau
                if(water.toInt() >75){

                    waterTank?.setImageResource(R.drawable.water_level_full)

                }else if(water.toInt() >50){

                    waterTank?.setImageResource(R.drawable.water_level_75)

                }else if(water.toInt() >25){

                    waterTank?.setImageResource(R.drawable.water_level_50)

                }else if(water.toInt() >5){

                    waterTank?.setImageResource(R.drawable.water_level_25)

                }else {
                    //envoie une notifcation toutes les 5min si le niveau d'eau est bas
                    if (notification) {
                        notificationManager.notify(notificationId, notificationBuilder.build())
                        notification=false
                        countDownTimer
                    }

                    waterTank?.setImageResource(R.drawable.water_level_empty)
                    if(water.toInt()<0){
                        water= 0
                    }


                }

                //affiche les différentes valeurs des capteur sur l'application
                waterPercentage?.text="$water%"
                humidityText?.text="$moisture%"
                temperatureIndicator?.text= "$temperature°C"
                lightText?.text=lightSensor.toString()



                //change l'image des boutton pour la lumière (on/off)
                (if(lightForce>0){
                    test?.setImageResource(R.drawable.ic_light)
                }else {
                    test?.setImageResource(R.drawable.ic_night)
                })

                //change l'image des boutton pour l'arrosage (on/off)
                (if(waterForce){
                    forceWatering?.setImageResource(R.drawable.baseline_water_drop_24)
                    warningWatering?.visibility=View.VISIBLE
                }else {
                    forceWatering?.setImageResource(R.drawable.ic_drop_off)
                    warningWatering?.visibility=View.INVISIBLE
                })



                //gere l'affichage visuel de l'aiguille de la jauge de teméparature
                if ((temperature + 10f) < 0f) {
                    rotationAiguille(-10f)
                }else if ((temperature + 10f) > 50f)
                {
                    rotationAiguille(50f)

                }else{

                    rotationAiguille(temperature)
                }
                rotationLightIndicator(lightSensor)







            }

            override fun onCancelled(error: DatabaseError) {
                showToast("ERROR DATABASE")
            }


        })





        // slider pour le niveau de luminosité des leds "classique"
        sliderLight?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                lightLevel?.text= progress.toString()
                lightIntensity=progress



            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Action à effectuer lorsque l'utilisateur commence à interagir avec le slide
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if ((lightForce>0|| !autoLight) && lightIntensity>0){
                    databaseRefPot.child("CMD").child("6_CMD_Light_manual_intensity").setValue(lightIntensity*10)
                }else if ((lightForce>0|| !autoLight)&&lightIntensity==0){
                    databaseRefPot.child("CMD").child("6_CMD_Light_manual_intensity").setValue(1)
                }


            }
        })



        // slider pour le niveau de luminosité des leds UV
        sliderUVLight?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                lightUVLevel?.text= progress.toString()
                lightUVIntensity=progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                // Action à effectuer lorsque l'utilisateur commence à interagir avec le slide
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {

                if ((lightForce>0|| !autoLight)&& lightUVIntensity>0){
                    databaseRefPot.child("CMD").child("9_CMD_UV_manual_intensity").setValue(lightUVIntensity*10)
                }else if ((lightForce>0|| !autoLight)&&lightUVIntensity==0){
                    databaseRefPot.child("CMD").child("9_CMD_UV_manual_intensity").setValue(1)
                }
            }
        })











        //bouton qui gere le passage du mode manuel au mode automatique de l'éclairage
        autoLightButton?.setOnClickListener(){

            if(autoLight){
                databaseRefPot.child("CMD").child("7_CMD_Light_manual_auto").setValue(false)
                Thread.sleep(100)
                databaseRefPot.child("CMD").child("a_CMD_UV_manual_auto").setValue(false)
            }
            if(!autoLight){
                databaseRefPot.child("CMD").child("7_CMD_Light_manual_auto").setValue(true)
                Thread.sleep(100)
                databaseRefPot.child("CMD").child("a_CMD_UV_manual_auto").setValue(true)
            }

        }

        forceWatering?.setOnClickListener(){

            if (waterForce){
                databaseRefPot.child("CMD").child("2_CMD_Pump_manual_on_off").setValue(false)
            }
            if (!waterForce){
                databaseRefPot.child("CMD").child("2_CMD_Pump_manual_on_off").setValue(true)
            }

        }
        Thread.sleep(100)

        //bouton qui gere le passage du mode manuel au mode automatique de l'arrosage
        autoWateringButton?.setOnClickListener(){

            if(waterAuto==true){
                databaseRefPot.child("CMD").child("4_CMD_Watering_manual_auto").setValue(false)
            }
            if(waterAuto==false){
                databaseRefPot.child("CMD").child("4_CMD_Watering_manual_auto").setValue(true)
            }

        }

        //bouton qui gere le forcage ou non de l'éclairage (nom pas encore défini)
        test?.setOnClickListener(){



            if(lightForce>0){
                databaseRefPot.child("CMD").child("6_CMD_Light_manual_intensity").setValue(0)
                Thread.sleep(100)
                databaseRefPot.child("CMD").child("9_CMD_UV_manual_intensity").setValue(0)
            }
            if(lightForce==0){


                if(lightIntensity==0){
                    databaseRefPot.child("CMD").child("6_CMD_Light_manual_intensity").setValue(1)
                }else {
                    databaseRefPot.child("CMD").child("6_CMD_Light_manual_intensity").setValue(lightIntensity*10)
                }
                Thread.sleep(100)

                if(lightUVIntensity==0){
                    databaseRefPot.child("CMD").child("9_CMD_UV_manual_intensity").setValue(1)
                }else {
                    databaseRefPot.child("CMD").child("9_CMD_UV_manual_intensity").setValue(lightUVIntensity*10)
                }


            }


        }


        return view
    }



    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when (requestCode) {
            0 -> {

            }
        }
    }

    private fun showToast(msg: String){

        Toast.makeText(context, msg,Toast.LENGTH_SHORT).show()

    }


}