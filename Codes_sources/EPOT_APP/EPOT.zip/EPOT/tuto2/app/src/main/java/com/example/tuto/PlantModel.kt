package com.example.tuto

class PlantModel(
    val id: String = "plant0",
    val name: String = "Tulipe",
    val description: String = "petite description",
    val imageUrl: String = "http://graven.yt/plante.jpg",
    val grow: Any = 1,
    val water: Any = 1,
    var liked: Boolean = false
)