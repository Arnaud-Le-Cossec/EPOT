package com.example.tuto.fragments

import android.app.Activity
import android.content.Context
import android.content.Context.INPUT_METHOD_SERVICE
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import com.example.tuto.MainActivity
import com.example.tuto.PlantModel
import com.example.tuto.PlantRepository
import com.example.tuto.PlantRepository.Singleton.downloadUri
import com.example.tuto.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.*



class AddPlantFragment(
    private val context: MainActivity
) : Fragment() {

    private var file:Uri? = null
    private var uploadedImage: ImageView?=null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater?.inflate(R.layout.fragment_add_plant,container, false)

        //recupere uploaded image pour lui associer son comosant
        uploadedImage = view?.findViewById(R.id.preview_image)

        //recuperer le button pour charger l'image
        val pickupImageButton = view?.findViewById<Button>(R.id.upload_button)

        //lorsque l'on clique dessus ouvre image téléphone
        pickupImageButton?.setOnClickListener{pickupImage()}

        //recuperer le boutton confirmer
        val confirmButton = view?.findViewById<Button>(R.id.confirm_button)

        confirmButton?.setBackgroundResource(R.drawable.view_selector)
        confirmButton?.setOnClickListener {sendForm(view)
            val inputMethodManager = requireContext().getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
            showToast("Plante ajouter avec succès")

        }





        return view
    }

    private fun showToast(msg: String){

        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    }

    private fun sendForm(view: View,) {
        val repo = PlantRepository()
        repo.uploadImage(file!!) {







            val plantName = view.findViewById<EditText>(R.id.name_input).text.toString()
            val plantDescription = view.findViewById<EditText>(R.id.description_input).text.toString()
            val grow = view.findViewById<Spinner>(R.id.grow_spinner).selectedItem
            val water = view.findViewById<Spinner>(R.id.water_spinner).selectedItem
            val downloadImageUrl = downloadUri

            //creer un nouvel objet de type plante model
            val plant = PlantModel(
                UUID.randomUUID().toString(),
                plantName,
                plantDescription,
                downloadImageUrl.toString(),
                grow,
                water
            )

            //envoyer en bdd
            repo.insertPlant(plant)
        }
    }


    private fun pickupImage() {
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        //startActivityForResult(Intent.createChooser(intent, "Select Picture"), 47)

        getResult.launch(Intent.createChooser(intent,"Select Picture"))


    }

    private val getResult =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){
            if (it.resultCode == Activity.RESULT_OK){

                //recuperer l'image qui a ete selectionner
                file = it.data?.data

                //mettre à jour l'appercu de l'image
                uploadedImage?.setImageURI(file)



            }
        }



}