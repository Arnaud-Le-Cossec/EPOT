package com.bluetooth.connection

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private var m_bluetoothAdapter: BluetoothAdapter? = null
    private lateinit var m_pairedDevices: Set<BluetoothDevice>
    private val REQUEST_ENABLE_BLUETOOTH = 1

    companion object {
        val EXTRA_ADDRESS: String = "Device_address"
    }

    @SuppressLint("MissingPermission", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        m_bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if(m_bluetoothAdapter == null) {
            Toast.makeText(this, "this device doesn't support bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (!m_bluetoothAdapter!!.isEnabled){
            val enableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBluetoothIntent, REQUEST_ENABLE_BLUETOOTH)
        }
        val refreshButton = findViewById<Button>(R.id.select_device_refresh)
        refreshButton.setOnClickListener { pairedDeviceList() }
        val quitButton = findViewById<Button>(R.id.quit_button)
        val packageName = "com.example.tuto"
        val activityName = "com.example.tuto.MainActivity"

        val intent = Intent().apply {
            setClassName(packageName, activityName)
        }
        quitButton.setOnClickListener{
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                // Gérer le cas où l'application n'est pas installée ou l'activité n'existe pas
            }

        }

    }

    @SuppressLint("MissingPermission")
    private fun pairedDeviceList() {
        m_pairedDevices = m_bluetoothAdapter!!.bondedDevices
        val list : ArrayList <BluetoothDevice> = ArrayList()
        val listName : ArrayList <String> = ArrayList()

        if(!m_pairedDevices.isEmpty()){
            for (device: BluetoothDevice in m_pairedDevices){

                list.add(device)
                listName.add(device.name)
                Log.i("device",""+device)
            }
        }else {
            Toast.makeText(this, "no paired device found", Toast.LENGTH_SHORT).show()
        }
        val adapter= ArrayAdapter(this, android.R.layout.simple_list_item_1, listName)
        val selectDeviceList = findViewById<ListView>(R.id.select_device_list)
        selectDeviceList.adapter= adapter
        selectDeviceList.onItemClickListener = AdapterView.OnItemClickListener{_, _, position, _ ->
            val device: BluetoothDevice = list[position]
            val address: String = device.address
            val intent = Intent(this, ControlActivity::class.java)
            intent.putExtra(EXTRA_ADDRESS, address)
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode== REQUEST_ENABLE_BLUETOOTH){
            if (resultCode == Activity.RESULT_OK){
                if (m_bluetoothAdapter!!.isEnabled) {
                    Toast.makeText(this, "Bluetooth has been enabled", Toast.LENGTH_SHORT).show()
                }else {
                    Toast.makeText(this, "Bluetooth has been disabled", Toast.LENGTH_SHORT).show()
                }
            }else if (resultCode== Activity.RESULT_CANCELED){
                Toast.makeText(this, "Bluetooth enableing has been canceled", Toast.LENGTH_SHORT).show()
            }
        }
    }
}